#!/usr/bin/env python3
"""
大航海期貨所 - 簡易聯機伺服器
- 房間建立 / 加入 / 等待室同步
- 開始遊戲通知
- 遊戲狀態快照轉發與重連恢復
"""
from __future__ import annotations

import asyncio
import json
import random
import string
from typing import Any, Dict, Optional, Set

import websockets
from websockets.server import WebSocketServerProtocol

HOST = "0.0.0.0"
PORT = 8766

# room_code -> room dict
rooms: Dict[str, Dict[str, Any]] = {}
# websocket -> meta
clients: Dict[WebSocketServerProtocol, Dict[str, Any]] = {}


def gen_code() -> str:
    chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    for _ in range(50):
        code = "SAIL-" + "".join(random.choice(chars) for _ in range(4))
        if code not in rooms:
            return code
    return "SAIL-" + "".join(random.choice(chars) for _ in range(6))


def public_room(room: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "code": room["code"],
        "maxPlayers": room["maxPlayers"],
        "status": room["status"],
        "players": room["players"],
        "hostId": room["hostId"],
    }


async def send(ws: WebSocketServerProtocol, payload: Dict[str, Any]) -> None:
    try:
        await ws.send(json.dumps(payload, ensure_ascii=False))
    except Exception:
        pass


async def broadcast_room(code: str, payload: Dict[str, Any], except_ws: Optional[WebSocketServerProtocol] = None) -> None:
    room = rooms.get(code)
    if not room:
        return
    dead: Set[WebSocketServerProtocol] = set()
    for ws in list(room["clients"]):
        if except_ws is not None and ws is except_ws:
            continue
        try:
            await ws.send(json.dumps(payload, ensure_ascii=False))
        except Exception:
            dead.add(ws)
    for ws in dead:
        room["clients"].discard(ws)
        clients.pop(ws, None)


async def handle_create(ws: WebSocketServerProtocol, data: Dict[str, Any]) -> None:
    name = (data.get("playerName") or "船長").strip()[:12] or "船長"
    try:
        max_players = int(data.get("maxPlayers") or 4)
    except Exception:
        max_players = 4
    max_players = max(2, min(5, max_players))

    code = gen_code()
    player = {
        "id": 1,
        "name": name,
        "isHost": True,
        "cash": 1000,
        "debt": 0,
        "holdings": {},
        "job": None,
        "jobTitle": "",
    }
    room = {
        "code": code,
        "maxPlayers": max_players,
        "status": "waiting",
        "hostId": 1,
        "nextId": 2,
        "players": [player],
        "clients": {ws},
        "gameState": None,
    }
    rooms[code] = room
    clients[ws] = {"code": code, "playerId": 1, "name": name}

    await send(ws, {
        "type": "created",
        "playerId": 1,
        "room": public_room(room),
    })


async def handle_join(ws: WebSocketServerProtocol, data: Dict[str, Any]) -> None:
    code = (data.get("code") or "").strip().upper()
    name = (data.get("playerName") or "航海士").strip()[:12] or "航海士"
    room = rooms.get(code)
    if not room:
        await send(ws, {"type": "error", "message": "房間不存在"})
        return
    if room["status"] != "waiting":
        # 允許觀戰式重連：同名或重連碼稍後擴充；先拒絕中途亂入
        await send(ws, {"type": "error", "message": "遊戲已開始，無法加入（可用重連）"})
        return
    if len(room["players"]) >= room["maxPlayers"]:
        await send(ws, {"type": "error", "message": "房間已滿"})
        return
    if any(p["name"] == name for p in room["players"]):
        name = f"{name}{random.randint(1, 99)}"

    pid = room["nextId"]
    room["nextId"] += 1
    player = {
        "id": pid,
        "name": name,
        "isHost": False,
        "cash": 1000,
        "debt": 0,
        "holdings": {},
        "job": None,
        "jobTitle": "",
    }
    room["players"].append(player)
    room["clients"].add(ws)
    clients[ws] = {"code": code, "playerId": pid, "name": name}

    await send(ws, {
        "type": "joined",
        "playerId": pid,
        "room": public_room(room),
    })
    await broadcast_room(code, {"type": "room_update", "room": public_room(room)})


async def handle_reconnect(ws: WebSocketServerProtocol, data: Dict[str, Any]) -> None:
    """用房間碼 + playerId 重連，取回最新遊戲快照。"""
    code = (data.get("code") or "").strip().upper()
    try:
        pid = int(data.get("playerId"))
    except Exception:
        await send(ws, {"type": "error", "message": "重連參數錯誤"})
        return
    room = rooms.get(code)
    if not room:
        await send(ws, {"type": "error", "message": "房間不存在或已解散"})
        return
    player = next((p for p in room["players"] if p["id"] == pid), None)
    if not player:
        await send(ws, {"type": "error", "message": "玩家不在此房間"})
        return

    room["clients"].add(ws)
    clients[ws] = {"code": code, "playerId": pid, "name": player["name"]}
    await send(ws, {
        "type": "reconnected",
        "playerId": pid,
        "room": public_room(room),
        "gameState": room.get("gameState"),
        "status": room["status"],
    })
    await broadcast_room(code, {
        "type": "player_online",
        "playerId": pid,
        "name": player["name"],
    }, except_ws=ws)


async def handle_start(ws: WebSocketServerProtocol, data: Dict[str, Any]) -> None:
    meta = clients.get(ws)
    if not meta:
        return
    room = rooms.get(meta["code"])
    if not room:
        return
    if meta["playerId"] != room["hostId"]:
        await send(ws, {"type": "error", "message": "只有房主可以開始遊戲"})
        return
    if len(room["players"]) < 2:
        await send(ws, {"type": "error", "message": "至少需要 2 位玩家"})
        return
    room["status"] = "playing"
    await broadcast_room(meta["code"], {
        "type": "game_start",
        "room": public_room(room),
    })


async def handle_game_state(ws: WebSocketServerProtocol, data: Dict[str, Any]) -> None:
    """儲存並轉發遊戲快照（方便斷線重連）。"""
    meta = clients.get(ws)
    if not meta:
        return
    room = rooms.get(meta["code"])
    if not room:
        return
    state = data.get("state")
    if state is None:
        return
    room["gameState"] = state
    await broadcast_room(meta["code"], {
        "type": "game_state",
        "fromPlayerId": meta["playerId"],
        "state": state,
    }, except_ws=ws)


async def handle_game_event(ws: WebSocketServerProtocol, data: Dict[str, Any]) -> None:
    """轉發單次操作事件給房內其他人。"""
    meta = clients.get(ws)
    if not meta:
        return
    room = rooms.get(meta["code"])
    if not room:
        return
    await broadcast_room(meta["code"], {
        "type": "game_event",
        "fromPlayerId": meta["playerId"],
        "event": data.get("event"),
        "payload": data.get("payload"),
    }, except_ws=ws)


async def handle_chat(ws: WebSocketServerProtocol, data: Dict[str, Any]) -> None:
    meta = clients.get(ws)
    if not meta:
        return
    text = (data.get("text") or "").strip()[:200]
    if not text:
        return
    await broadcast_room(meta["code"], {
        "type": "chat",
        "playerId": meta["playerId"],
        "name": meta["name"],
        "text": text,
    })


async def on_message(ws: WebSocketServerProtocol, raw: str) -> None:
    try:
        data = json.loads(raw)
    except Exception:
        await send(ws, {"type": "error", "message": "訊息格式錯誤"})
        return
    t = data.get("type")
    if t == "create":
        await handle_create(ws, data)
    elif t == "join":
        await handle_join(ws, data)
    elif t == "reconnect":
        await handle_reconnect(ws, data)
    elif t == "start":
        await handle_start(ws, data)
    elif t == "game_state":
        await handle_game_state(ws, data)
    elif t == "game_event":
        await handle_game_event(ws, data)
    elif t == "chat":
        await handle_chat(ws, data)
    elif t == "ping":
        await send(ws, {"type": "pong"})
    else:
        await send(ws, {"type": "error", "message": f"未知指令: {t}"})


async def on_connect(ws: WebSocketServerProtocol) -> None:
    clients[ws] = {}
    await send(ws, {"type": "hello", "message": "大航海期貨所聯機伺服器", "port": PORT})
    try:
        async for raw in ws:
            await on_message(ws, raw)
    finally:
        meta = clients.pop(ws, None) or {}
        code = meta.get("code")
        pid = meta.get("playerId")
        if not code or code not in rooms:
            return
        room = rooms[code]
        room["clients"].discard(ws)
        # 等待中：移除離線玩家；遊戲中：保留座位以便重連
        if room["status"] == "waiting" and pid is not None:
            room["players"] = [p for p in room["players"] if p["id"] != pid]
            if not room["players"]:
                rooms.pop(code, None)
                return
            if room["hostId"] == pid:
                room["hostId"] = room["players"][0]["id"]
                room["players"][0]["isHost"] = True
            await broadcast_room(code, {"type": "room_update", "room": public_room(room)})
        else:
            await broadcast_room(code, {
                "type": "player_offline",
                "playerId": pid,
                "name": meta.get("name"),
            })


async def main() -> None:
    print(f"[期貨所聯機] ws://0.0.0.0:{PORT}")
    async with websockets.serve(on_connect, HOST, PORT, ping_interval=20, ping_timeout=20):
        await asyncio.Future()


if __name__ == "__main__":
    asyncio.run(main())
