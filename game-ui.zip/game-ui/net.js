/**
 * 大航海期貨所 - 聯機客戶端
 * 預設連 ws://目前主機:8766 ，可在 localStorage.netUrl 覆寫
 */
(function (global) {
  const DEFAULT_PORT = 8766;

  function defaultUrl() {
    const saved = localStorage.getItem('netUrl');
    if (saved) return saved;
    const host = location.hostname || '127.0.0.1';
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    // file:// 開啟時 hostname 為空
    if (!location.hostname || location.protocol === 'file:') {
      return `ws://127.0.0.1:${DEFAULT_PORT}`;
    }
    return `${proto}//${host}:${DEFAULT_PORT}`;
  }

  const Net = {
    ws: null,
    url: defaultUrl(),
    connected: false,
    playerId: null,
    room: null,
    handlers: {},
    _queue: [],
    _retry: 0,
    _intentionalClose: false,

    on(type, fn) {
      if (!this.handlers[type]) this.handlers[type] = [];
      this.handlers[type].push(fn);
    },
    off(type, fn) {
      if (!this.handlers[type]) return;
      this.handlers[type] = this.handlers[type].filter((f) => f !== fn);
    },
    emit(type, data) {
      (this.handlers[type] || []).forEach((fn) => {
        try { fn(data); } catch (e) { console.error(e); }
      });
      (this.handlers['*'] || []).forEach((fn) => {
        try { fn(type, data); } catch (e) { console.error(e); }
      });
    },

    setUrl(url) {
      this.url = url;
      localStorage.setItem('netUrl', url);
    },

    connect() {
      if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
        return;
      }
      this._intentionalClose = false;
      try {
        this.ws = new WebSocket(this.url);
      } catch (e) {
        this.emit('error', { message: '無法建立連線：' + e.message });
        return;
      }
      this.ws.onopen = () => {
        this.connected = true;
        this._retry = 0;
        this.emit('open', {});
        while (this._queue.length) {
          this.ws.send(this._queue.shift());
        }
      };
      this.ws.onclose = () => {
        this.connected = false;
        this.emit('close', {});
        if (!this._intentionalClose) {
          const delay = Math.min(8000, 1000 * Math.pow(1.5, this._retry++));
          setTimeout(() => this.connect(), delay);
        }
      };
      this.ws.onerror = () => {
        this.emit('error', { message: '連線失敗，請確認聯機伺服器是否啟動（埠 8766）' });
      };
      this.ws.onmessage = (ev) => {
        let data;
        try { data = JSON.parse(ev.data); } catch (_) { return; }
        if (data.type === 'created' || data.type === 'joined' || data.type === 'reconnected') {
          this.playerId = data.playerId;
          this.room = data.room;
          localStorage.setItem('myPlayerId', String(data.playerId));
          if (data.room) localStorage.setItem('currentRoom', JSON.stringify(data.room));
          localStorage.setItem('onlineMode', '1');
        }
        if (data.type === 'room_update' && data.room) {
          this.room = data.room;
          localStorage.setItem('currentRoom', JSON.stringify(data.room));
        }
        if (data.type === 'game_start' && data.room) {
          this.room = data.room;
          localStorage.setItem('currentRoom', JSON.stringify(data.room));
          localStorage.setItem('onlineMode', '1');
        }
        this.emit(data.type, data);
      };
    },

    close() {
      this._intentionalClose = true;
      if (this.ws) this.ws.close();
    },

    send(obj) {
      const raw = JSON.stringify(obj);
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(raw);
      } else {
        this._queue.push(raw);
        this.connect();
      }
    },

    createRoom(playerName, maxPlayers) {
      this.send({ type: 'create', playerName, maxPlayers });
    },
    joinRoom(code, playerName) {
      this.send({ type: 'join', code: (code || '').toUpperCase(), playerName });
    },
    reconnect(code, playerId) {
      this.send({ type: 'reconnect', code: (code || '').toUpperCase(), playerId: parseInt(playerId, 10) });
    },
    startGame() {
      this.send({ type: 'start' });
    },
    pushState(state) {
      this.send({ type: 'game_state', state });
    },
    sendEvent(event, payload) {
      this.send({ type: 'game_event', event, payload });
    },
    isOnline() {
      return localStorage.getItem('onlineMode') === '1';
    },
    clearOnline() {
      localStorage.removeItem('onlineMode');
    }
  };

  global.GameNet = Net;
})(window);
